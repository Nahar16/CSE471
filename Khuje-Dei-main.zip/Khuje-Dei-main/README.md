# khuje_dei
